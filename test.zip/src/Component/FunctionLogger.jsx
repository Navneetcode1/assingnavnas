import React, { useState, useEffect, useCallback } from "react";

const FunctionLogger = () => {
    const [count, setCount] = useState(0);

    useEffect(() => {
        console.log("Component has mounted");

        return () => {
            console.log("Component will unmount");
        };
    }, []);

    const getDerivedStateFromProps = useCallback(() => {
        console.log("Syncing state with props");
    }, []);

    useEffect(() => {
        getDerivedStateFromProps();
    }, [getDerivedStateFromProps]);

    const shouldComponentUpdate = useCallback((nextProps, nextState) => {
        console.log("Component will rerender");
        return true;
    }, []);

    const getSnapshotBeforeUpdate = useCallback((prevProps, prevState) => {
        console.log("Snapshot before DOM updates");
        return null;
    }, []);

    useEffect(() => {
        const prevCount = count;
        const snapshot = getSnapshotBeforeUpdate(null, prevCount);

        console.log("Component has updated", snapshot);
    }, [count, getSnapshotBeforeUpdate]); 

    return (
        <div>
            <p>count: {count}</p>
            <button onClick={() => setCount(count + 1)}>Update</button>
        </div>
    );
};

export default FunctionLogger;
