import React, { Component } from "react";

class LifeCycleLogger extends Component {
    constructor(props) {
        super(props);
        this.state = {
            count: 0
        };
        console.log("Component is constructed");
    }

    static getDerivedStateFromProps(props, state) {
        console.log("Syncing state with props");
        return null;
    }

    componentDidMount() {
        console.log("Component has mounted");
    }

    shouldComponentUpdate(nextProps, nextState) {
        console.log("Component will rerender");
        return true;
    }

    getSnapshotBeforeUpdate(prevProps, prevState) {
        console.log("Snapshot before DOM updates");
        return null;
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        console.log("Component has updated");
    }

    componentWillUnmount() {
        console.log("Component will unmount");
    }

    render() {
        console.log("Rendering");
        return (
            <div>
                <p>count: {this.state.count}</p>
                <button onClick={() => this.setState({ count: this.state.count + 1 })}>Update</button>
            </div>
        );
    }
}

export default LifeCycleLogger;
