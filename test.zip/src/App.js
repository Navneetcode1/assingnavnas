import logo from './logo.svg';
import './App.css';
import LifeCycleLogger from './Component/LifeCycleLogger';
import FunctionLogger from './Component/FunctionLogger';

function App() {
  return (
    <div className="App">
      <LifeCycleLogger/>// class one
      <FunctionLogger/> //the functionone
    </div>
  );
}

export default App;
